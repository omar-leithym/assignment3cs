#include "customer.h"

customer::customer() {
	mechanicId = 0;
	name = "";
	id = 0;
	age = 0;
}

customer::customer(string n, int i, int a) {
	name = n;
	id = i;
	age = a;
	mechanicId = 0;
}
void customer::setMecId(int i) {
	mechanicId = i;
}
int customer::getMecId() {
	return mechanicId;
}
void customer::setTime(appointment t) {
	time.hours = t.hours;
	time.minutes = t.minutes;
}
appointment customer::getTime() {
	return time;
}
bool customer::operator==(customer a) {
	return time.hours == a.getTime().hours && time.minutes == a.getTime().minutes;
}
bool customer::operator>(customer a) {
	int total1 = time.hours * 60 + time.minutes;
	int total2 = a.getTime().hours * 60 + a.getTime().minutes;
	return total1 > total2;
}
bool customer::operator<(customer a) {
	int total1 = time.hours * 60 + time.minutes;
	int total2 = a.getTime().hours * 60 + a.getTime().minutes;
	return total1 < total2;
}
