#include "mechanic.h"
#include <iostream>
using namespace std;

mechanic::mechanic() {
	counter = 0;
	name = "";
	id = 0;
	age = 0;
	maxx = 0;
}

mechanic::mechanic(string n, int i, int a) {
	name = n;
	id = i;
	age = a;
}
bool mechanic::isAvailable(appointment a) {
	if (counter == maxx) {
		return false;
	}
	for (int i = 0; i < counter; i++) {
		if (times[i].hours == a.hours && times[i].minutes == a.minutes) {
			return false;
		}
	}
	return true;
}
void mechanic::setApp(appointment a) {
	times[counter++] = a;
}
void mechanic::getApp() {
	for (int i = 0; i < counter; i++) {
		cout << "Appointment at: " << times[i].hours << ":" << times[i].minutes << endl;
	}
}

void mechanic::setTimes(int n) {
	times = new appointment[n];
	maxx = n;
}
int mechanic::getNum() {
	return counter;
}

mechanic::~mechanic() {
		delete[] times;
}