#include <iostream>
#include <fstream>
#include <string>
#include "appointment.h"
#include "mechanic.h"
#include "person.h"
#include "customer.h"
#include "queue.h"
using namespace std;

int main() {

	ifstream mech("mechanics.txt"); // ifstream to reead from files mechanics and customers
	ifstream customers("customers.txt");
	string size_customers, size; // reads the size of both mechanics and customers which is the first number at the top
	getline(mech, size);
	mechanic* mechanics = new mechanic[stoi(size.c_str())]; // declares a dynamic array of mechanics with the size
	getline(customers, size_customers);
	customer* all_customers = new customer[stoi(size_customers.c_str())]; // declares a dynamic array of customers with the size
	string name, age, id, appointments_num, hrs, mins; // variables to store the information of the mechanic
	for (int i = 0; i < stoi(size.c_str()); i++) { // loop to read the information of the mechanics
		getline(mech, name);
		getline(mech, age); // puts the data from the file into the variables
		getline(mech, id);
		getline(mech, appointments_num);
		mechanic x(name, stoi(id.c_str()), stoi(age.c_str())); // constructs a mechanic  with these attributes
		x.setTimes(stoi(size_customers.c_str())); // sets the dyanmic array to the size of customers
		for (int j = 0; j < stoi(appointments_num.c_str()); j++) {
			getline(mech, hrs); // loops for the number of appointments and makes an appointment with the data
			getline(mech, mins);
			appointment y; y.hours = stoi(hrs.c_str()); y.minutes = stoi(mins.c_str());
			x.setApp(y); // sets the appointment for the mechanic
		}
		mechanics[i] = x; // adds the mechanic to the array
	}
	for (int j = 0; j < stoi(size_customers.c_str()); j++) {
		getline(customers, name); // reads the attributes of the customer
		getline(customers, age);
		getline(customers, id);
		customer x(name, stoi(id.c_str()), stoi(age.c_str())); // constructs a customer with the data
		appointment y;
		getline(customers, hrs); // creates an appointment and sets it to the customer
		getline(customers, mins);
		y.hours = stoi(hrs.c_str()); y.minutes = stoi(mins.c_str());
		x.setTime(y);
		all_customers[j] = x; // adds the customer to the array
	}
	mech.close(); // closes the files
	customers.close();
	int size_int = stoi(size.c_str());
	int size_customers_int = stoi(size_customers.c_str());
	for (int j = 0; j < size_customers_int; j++) { // loop to set each customer to their mechanic
		if (mechanics[j % size_int].isAvailable(all_customers[j].getTime())) { // checks if the first mechanic is available at the customers time
			mechanics[j % size_int].setApp(all_customers[j].getTime()); // if the mechanic is availabe, the time is set
			all_customers[j].setMecId(mechanics[j % size_int].getId()); // the MechanicId is set in the customer class
		}
		else if (mechanics[(j + 1) % 3].isAvailable(all_customers[j].getTime())) { // does the same with the second mechanic
			mechanics[(j + 1) % size_int].setApp(all_customers[j].getTime());
			all_customers[j].setMecId(mechanics[(j + 1) % size_int].getId());
		}

		else if (mechanics[(j + 2) % size_int].isAvailable(all_customers[j].getTime())) { // does the same with the third mechanic
			mechanics[(j + 2) % size_int].setApp(all_customers[j].getTime());
			all_customers[j].setMecId(mechanics[(j + 2) % size_int].getId());
		}
		else {
			cout << "Sorry " << all_customers[j].getName() << ", no mechanic is available at this time!" << endl; // if no mechanic is avaible, prints this error message
		}
	}
	for (int i = 0; i < size_customers_int; i++) {
		for (int j = i; j < size_customers_int; j++) { // loops through the array to sort them in terms of the appointment times
			if (all_customers[j] < all_customers[i]) {
				swap(all_customers[j], all_customers[i]);
			}
		}
	}
	queue<customer> ordered_list; // declaring a queue with type customer
	for (int i = 0; i < size_customers_int; i++) { // loops through the customers array
		if(all_customers[i].getMecId() != 0) { // if the customer is assigned to a mechanic
			ordered_list.push(all_customers[i]); // pushes the customer into the queue
			all_customers[i].printInfo(); // prints the info of the customer
			cout << " is assigned to Mechanic: ";
			mechanics[all_customers[i].getMecId()-1].printInfo(); // princt the info of the mechanic they're assigned to
			cout << " at " << all_customers[i].getTime().hours << ":" << all_customers[i].getTime().minutes << endl; // and prints the appointment time
		}
	}

}