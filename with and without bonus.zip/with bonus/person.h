#pragma once
#include <string>
using namespace std;
class person {

protected:
	string name; // protected variables name, id and age
	int id;
	int age;
public:
	person(); // overloaded constructor that intializes the variables
	person(string n, int i, int a);
	void setName(string n); // setter for the name
	string getName(); // getter for the name
	void setAge(int a); // setter for the age
	int getAge(); // getter for the age
	void setId(int i); // setter for the id
	int getId(); // getter for the id
	void printInfo(); // prints the person's information
};
