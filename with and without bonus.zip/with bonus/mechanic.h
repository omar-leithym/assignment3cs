#pragma once
#include "person.h"
#include "appointment.h"

class mechanic : public person {
private:
	int counter; // private variables counter and dyanmic array of appointments
	appointment *times;
	int maxx;
public:
	mechanic(); // overloaded constructor that intializes variables
	mechanic(string n, int i, int a);
	~mechanic(); // destructor to return the borrowed memory to the heap
	bool isAvailable(appointment a); // checks if the mechanic is avaialable at a certain appointment time
	void setApp(appointment a); // sets appointment for mechanic
	void getApp(); // prints info of all appointments
	void setTimes(int n); // declares size of the dynamic array
	int getNum(); // returns the number of appointments
};
