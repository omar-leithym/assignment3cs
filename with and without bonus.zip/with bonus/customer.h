#pragma once
#include "person.h"
#include "appointment.h"

class customer : public person { // class customer than inherits from person
private:
	int mechanicId; // private variables mechanicID and time for their appointment
	appointment time;
public:
	customer(); // overloaded constructor that intitalizes the variables including those inherited from person
	customer(string n, int i, int a);
	void setMecId(int i); // setter and getter for MechanicID
	int getMecId();
	void setTime(appointment t); // setter and getter for the appointment
	appointment getTime();
	bool operator==(customer a); // overloaded operators to compare times between different customers
	bool operator>(customer a);
	bool operator<(customer a);
};