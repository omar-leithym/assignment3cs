#pragma once

template <class T>
class queue { // template class queue
private:
	int top; // private variable top, bot and array of type T
	int bot;
	T arr[20];
public:
	queue() {
		top = -1; // constructor intializes variables
		bot = 0;
	}
	void push(T element) { // push adds an element to the array
		arr[++top] = element;
	}
	void pop() { // pop removes an element from the array
		bot++;
	}
};