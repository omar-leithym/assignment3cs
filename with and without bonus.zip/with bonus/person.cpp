#include "person.h"
#include <iostream>
using namespace std;


person::person() {
	name = "";
	id = 0;
	age = 0;
}
person::person(string n, int i, int a) {
	name = n;
	id = i;
	age = a;
}
void person::setName(string n) {
	name = n;
}
string person::getName() {
	return name;
}
void person::setAge(int a) {
	age = a;
}
int person::getAge() {
	return age;
}
void person::setId(int i) {
	id = i;
}
int person::getId() {
	return id;
}
void person::printInfo() {
	cout << "Name: " << name << " Age: " << age;
}

