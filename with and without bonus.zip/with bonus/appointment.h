#pragma once

struct appointment { // struct appointment that has only 2 variables, hours and minutes which are both initialized to 0
	int hours = 0;
	int minutes = 0;
};

