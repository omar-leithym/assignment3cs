#include <iostream>
#include "appointment.h"
#include "mechanic.h"
#include "person.h"
#include "customer.h"
#include "queue.h"
using namespace std;

int main() {
	mechanic mechanics[3]; // array of size 3 of mechanics
	mechanic ayman("Ayman", 1, 30), khaled("Khaled", 2, 35), mai("Mai", 3, 40); // declaring 3 mechanics 
	mechanics[0] = ayman; mechanics[1] = khaled; mechanics[2] = mai; // putting the mechanics in the array
	string name; int age, hours, minutes, size; appointment app; // declarations needed for the input of the user
	cout << "Enter the number of customers: "; // Asks the user to enter the number of customers
	cin >> size;
	customer* all_customers = new customer[size]; // creates a new dynamic array with size "size"
	for (int i = 0; i < 3; i++) {
		mechanics[i].setTimes(size); // sets the maximum appointments of each mechanic to "size"
	}
	for(int i=0; i <size; i++) { // loops to input information for all customers
		cout << "PLease enter the customer " << i + 1 << "'s name: "; // asks the user to input the customer's name
		cin >> name;
		cout << "Please enter the customer " << i + 1 << "'s age: "; // asks the user to input the customer's age
		cin >> age;
		do {
			cout << "Please enter the hour (0-24) for the appointment: "; // validation to make sure the user enters a correct 24 hour format time
			cin >> hours;
			cout << "Please enter the minutes (0-60) for the appointment: ";
			cin >> minutes;
		} while (hours > 24 || hours < 0 || minutes < 0 || minutes > 60);
		app.minutes = minutes; // sets the appointment to these times
		app.hours = hours;
		int id = i + 1; // ascending id is equal to i+1
		customer x(name, id, age); // makes a customer with these attributes
		x.setTime(app); // sets the time of the appointment
		all_customers[i] = x; // adds the customer to the array
	}
	for (int j = 0; j < size; j++) { // loop to set each customer to their mechanic
		if (mechanics[j % 3].isAvailable(all_customers[j].getTime())) { // checks if the first mechanic is available at the customers time
			mechanics[j % 3].setApp(all_customers[j].getTime()); // if the mechanic is availabe, the time is set
			all_customers[j].setMecId(mechanics[j % 3].getId()); // the MechanicId is set in the customer class
		}
		else if (mechanics[(j + 1) % 3].isAvailable(all_customers[j].getTime())) { // does the same with the second mechanic
			mechanics[(j + 1) % 3].setApp(all_customers[j].getTime());
			all_customers[j].setMecId(mechanics[(j + 1) % 3].getId());
		}

		else if (mechanics[(j + 2) % 3].isAvailable(all_customers[j].getTime())) { // does the same with the third mechanic
			mechanics[(j + 2) % 3].setApp(all_customers[j].getTime());
			all_customers[j].setMecId(mechanics[(j + 2) % 3].getId());
		}
		else {
			cout << "Sorry " << all_customers[j].getName() << ", no mechanic is available at this time!" << endl; // if no mechanic is avaible, prints this error message
		}
	}
	for (int i = 0; i < size; i++) {
		for (int j = i; j < size; j++) { // loops through the array to sort them in terms of the appointment times
			if (all_customers[j] < all_customers[i]) {
				swap(all_customers[j], all_customers[i]);
			}
		}
	}
	queue<customer> ordered_list; // declaring a queue with type customer
	for (int i = 0; i < size; i++) { // loops through the customers array
		if(all_customers[i].getMecId() != 0) { // if the customer is assigned to a mechanic
			ordered_list.push(all_customers[i]); // pushes the customer into the queue
			all_customers[i].printInfo(); // prints the info of the customer
			cout << " is assigned to Mechanic: ";
			mechanics[all_customers[i].getMecId()-1].printInfo(); // princt the info of the mechanic they're assigned to
			cout << " at " << all_customers[i].getTime().hours << ":" << all_customers[i].getTime().minutes << endl; // and prints the appointment time
		}
	}

	delete[] mechanics; // returns the borrowed memory to the heap
	delete[] all_customers;
}